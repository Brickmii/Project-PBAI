# introspector module - thought box of system
# capable of providing motion vector calculation based on motion calendar
# may call randomizer for random function from keystone
# random function may be assessed for viability
# introspector may accept or reject
# introspector may only accept righteous functions from randomizer
# introspector will reject non-righteous functions from randomizer