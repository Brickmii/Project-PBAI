# value storage kernel for evaluator,
# stores any and all learned values,
# assesses value along proper axes of righteousness,
# is volatile because values can change,
# values change when no longer true along  proper axes of righteousness,
# will not change values until verified false,
# values between true and false are classified maybe values along proper axes of righteousness