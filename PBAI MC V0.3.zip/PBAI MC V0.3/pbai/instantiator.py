# Instantiator module - responsible for executing one action from choice set from comptroller
# instantiator may not choose noop
# instantiator is obligated to act when gated through comptroller
# instantiator triggers golden gate learning loop
# registrar opens gate if new information is gained