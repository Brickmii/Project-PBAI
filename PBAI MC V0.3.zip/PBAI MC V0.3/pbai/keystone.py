# keystone module - function kernel,
# function kernel for core,
# only accessible through core,
# only connection to randomizer