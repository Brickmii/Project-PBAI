# Randomizer module,
# provides random entropy injection,
# only core and introspector require injection,
# core requires entropy on birth event,
# entropy injection provides keystone identity,
# introspector also requires entropy injection,
# main function of randomizer
# keystone stores learned function,
# randomizer may give introspector random function from keystone through core through api