# Comptroller module,
# responsible for managing introspector suggested functions,
# provides instantiator with righteous values for relevant functions,
# comptroller may provide noop if no righteous values are present for any present function