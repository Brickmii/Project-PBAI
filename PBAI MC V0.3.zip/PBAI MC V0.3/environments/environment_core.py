# Environment core module
# Interface module for drivers and ports
# Responsible for carrying all environmental information to system
# Responsible for directing drivers and ports from task input
# Responsible for directing drivers and ports from instantiator output
# Connects to api
# No other modules connect to environment core