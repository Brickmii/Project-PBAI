# Execute demo run pbai in bigmaze in tasks directory,
# executes actual playable script bigmazy.py,
# pbai plays maze,
# access to all buttons,
# pbai is not programmed to learn,
# pbai should grow its information state size to learn the mazes,
# pbai should understand a maze goal has been met,
# pbai should continue to run mazes by pressing new maze,
# pbai may press restart