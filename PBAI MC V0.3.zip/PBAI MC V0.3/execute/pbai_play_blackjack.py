# Execute demo run pbai in blackjack in tasks directory,
# executes actual playable script blackjack.py,
# pbai plays blackjack,
# access to all buttons,
# pbai is not programmed to learn,
# pbai should grow its information state size to learn the cards and game,
# pbai should understand an information growth goal has been met,
# pbai should develop effective strategies,
# pbai may decide any and all effective strategy to preserve value