# Goldmember diagnostic module
# removable, included in base for debug,
# designed to bootstrap api, golden loop, golden gate
# Golden Gate - Registrar learning gate diagnosis
# Golden Loop - Evaluator learning gate diagnosis
# may be ran alongside tasks to assess learning
# is not a standalone diagnosis program
# assesses difference between information given and information learned
# may be adjusted or added to for functional completion